## 相关网站：

1. yd-dlp：https://github.com/yt-dlp/yt-dlp
    - 支持的平台：https://github.com/yt-dlp/yt-dlp/blob/master/supportedsites.md
2. metube：https://github.com/alexta69/metube
3. [工作流文件(点击下载)](../workflows/video_collection.json)

## 安装指令：

```bash
## 安装metube

1. 下载并安装docker：https://www.docker.com/
2. 进入自定义的文件夹，下载metube：
git clone https://github.com/alexta69/metube.git
3. 进入metube文件夹，执行：
docker build -t metube-local .
4. 运行metube容器：
docker run -d \
  --name metube \
  -p 8081:8081 \
  -e DOWNLOAD_DIR=/downloads \
  -e YTDL_OPTIONS='{"writesubtitles":true,"writethumbnail":true,"updatetime":false}' \
  -v 填写你本地的目录/downloads:/downloads \ 
  metube-local
* 这里的\换行符要根据自己的终端来改，不确定的话，可以把命令发给 AI，告诉它你用的是什么终端，让它帮你转换。比如转成powershell
* -v 后面的路径（比如 D:/works/n8ndata/downloads）一定要改成你自己电脑上的实际路径，不然下载的文件会保存不了

5. 打开metube：http://localhost:8081/
```

## N8N系统课程

### 《AI自动化大师课：从零构建企业级工作流》

🔥 过去2年，我深耕AI应用实战，分享了近200期内容。一路追逐各种新AI工具的经历，让我明白了一个道理：
> 与其囤积更多AI工具，不如打造一个真正高效的自动化系统!!!

经过半年的研究和实践，我用N8N搭建了各种自动化工作流：从内容创作到数据分析，从社媒运营到粉丝管理，这些流程每天24小时都在帮我干活。

现在，我把这些经验整理成了一门系统课程《AI自动化大师课：从零构建企业级工作流》。无论你是新手还是进阶用户，这里都有大量实用技巧和解决方案，帮你快速掌握工作流自动化，让AI真正成为你的得力助手。
  > 课程地址：https://ailinplus-s-school.teachable.com/p/ai
  
  课程里不仅有很多直接可用的企业级工作流模板，更重要的是会教你怎么根据自己的实际需求来定制工作流。
  
  
👉 通过这门课程，你将学会：
1. 工作流的基础知识
2. N8N的部署和升级技巧
3. 快速上手N8N及其避坑指南
4. 各种N8N使用问题的解决方案
5. 最大化工作流中AI的应用价值
6. 构建企业级工作流的完整能力

我会从最基础的概念讲起，循序渐进地帮助大家掌握工作流自动化的核心。不管你是新手，还是已经有一定自动化经验的进阶用户，在这门课里都能学到非常多的实用技巧和解决方案，我用了大量的实例来讲解，帮你少走弯路，降低学习曲线的陡峭程度，让你能快速上手并马上用到工作中。
> 咨询课程问题可添加微信：ailinplus

![wx_ailinplus](../automation.jpg)